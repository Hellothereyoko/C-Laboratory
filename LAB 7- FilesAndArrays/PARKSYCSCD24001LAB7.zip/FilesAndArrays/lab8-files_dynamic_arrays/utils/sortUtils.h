#ifndef SORTUTILS_H
#define SORTUTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void selectionSort(int * array, int total);

#endif